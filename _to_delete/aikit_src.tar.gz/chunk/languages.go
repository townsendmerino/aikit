package chunk

import (
	"path"
	"strings"
)

// extLang maps a lowercased file extension (with dot) to a canonical
// language name. It mirrors the spirit of semble's sources.FILE_TYPES.
//
// Only the five names python/go/typescript/java/rust are handled by the
// regex chunker (ken's DESIGN.md v1). JavaScript variants intentionally route to
// "typescript": the two share one regex ruleset (ken's DESIGN.md §2 groups
// "TypeScript/JavaScript"). Everything else gets a descriptive name that
// is simply not in regex.SupportedLanguages(), so ChunkFile falls back to
// the line chunker for it.
var extLang = map[string]string{
	".py": "python", ".pyi": "python",
	".go": "go",
	".ts": "typescript", ".tsx": "typescript", ".mts": "typescript", ".cts": "typescript",
	".js": "typescript", ".jsx": "typescript", ".mjs": "typescript", ".cjs": "typescript",
	".java": "java",
	".rs":   "rust",

	// Languages tree-sitter chunks but the regex chunker does not (these
	// fall through to the line chunker under --chunker=regex, and get
	// AST chunking under --chunker=treesitter).
	".c": "c", ".h": "c", ".cc": "cpp", ".cpp": "cpp", ".hpp": "cpp", ".cxx": "cpp",
	".rb": "ruby", ".php": "php", ".cs": "csharp", ".swift": "swift",
	".kt": "kotlin", ".kts": "kotlin", ".scala": "scala", ".sc": "scala",
	".m": "objc", ".mm": "objc",
	".sh": "shell", ".bash": "shell", ".zsh": "shell",
	".ex": "elixir", ".exs": "elixir",
	".hs":  "haskell",
	".lua": "lua",
	".zig": "zig",

	// Known data/markup formats (no chunker handles these yet — line fallback).
	".md": "markdown", ".rst": "rst", ".txt": "text",
	".json": "json", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
	".xml": "xml", ".html": "html", ".css": "css", ".scss": "css",
	".sql": "sql", ".proto": "proto", ".graphql": "graphql",
}

// Language returns the canonical language for a path, or "" if unknown.
// Some basenames are recognized without an extension.
func Language(p string) string {
	base := strings.ToLower(path.Base(p))
	switch base {
	case "dockerfile":
		return "dockerfile"
	case "makefile", "gnumakefile":
		return "make"
	case "go.mod", "go.sum":
		return "gomod"
	}
	ext := strings.ToLower(path.Ext(base))
	return extLang[ext]
}
