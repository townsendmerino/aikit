package ann

import (
	"fmt"
	"math"
	"math/rand/v2"
	"testing"
)

// dimForBench matches the Model2Vec checkpoint's output dimension — its
// embeddings tensor is [vocab, 256].
// Synthetic vectors at this width keep the benchmark realistic relative
// to what ken's embed pipeline actually feeds Flat in production.
const dimForBench = 256

// makeUnitVectors generates n L2-normalized random vectors of dim d
// using a seeded PRNG. Determinism: same (n, d, seed) → identical
// vectors, so benchstat compares across runs cleanly.
//
// The Flat type's invariant (vectors must be L2-normalized) is enforced
// at the embed boundary in production; we honour it here so the
// benchmark exercises the same code path the production retriever does.
func makeUnitVectors(n, d int, seed uint64) [][]float32 {
	rng := rand.New(rand.NewPCG(seed, seed^0xdeadbeef))
	out := make([][]float32, n)
	for i := range out {
		v := make([]float32, d)
		var sumsq float64
		for j := range v {
			x := float32(rng.NormFloat64())
			v[j] = x
			sumsq += float64(x) * float64(x)
		}
		inv := float32(1.0 / math.Sqrt(sumsq))
		for j := range v {
			v[j] *= inv
		}
		out[i] = v
	}
	return out
}

func BenchmarkFlatQuery(b *testing.B) {
	// N values per the briefing: prediction #3 says flat search becomes
	// intractable at chromium-scale (~millions of chunks). The per-N
	// curve here lets a Phase-1 benchstat run trace the O(N·D) line and
	// pick a hand-off threshold for HNSW (DESIGN.md §10 future work).
	//
	// Max N is 50k rather than the briefing's 100k — judgment call #3,
	// dropping to keep a single bench iteration under a couple seconds
	// on this laptop. Phase 1 can bump back to 100k if the harness lives
	// on better hardware.
	cases := []struct {
		name string
		n    int
	}{
		{"N1k", 1_000},
		{"N10k", 10_000},
		{"N50k", 50_000},
	}
	for _, tc := range cases {
		b.Run(tc.name, func(b *testing.B) {
			corpus := makeUnitVectors(tc.n, dimForBench, 0xfeed)
			query := makeUnitVectors(1, dimForBench, 0xdade)[0]
			f := New(corpus)
			// SetBytes is the per-iteration work: N vectors × dim × 4 B
			// (float32 dot products). benchstat MB/s then reads as
			// flat-scan memory bandwidth.
			b.SetBytes(int64(tc.n) * int64(dimForBench) * 4)
			b.ReportAllocs()
			b.ResetTimer()
			for i := 0; i < b.N; i++ {
				_ = f.Query(query, 10)
			}
		})
	}
}

// BenchmarkFlatQuery_scale covers the SIMD-dot task's grid at the two real model
// dimensions — 256 (Model2Vec) and 768 (the CodeRankEmbed encoder) — across
// N=10k/100k: the larger d and N that show the linalg.Dot/Dot8x4 win at scale.
func BenchmarkFlatQuery_scale(b *testing.B) {
	for _, d := range []int{256, 768} {
		for _, n := range []int{10_000, 100_000} {
			b.Run(fmt.Sprintf("d%d/N%d", d, n), func(b *testing.B) {
				corpus := makeUnitVectors(n, d, 0xfeed)
				query := makeUnitVectors(1, d, 0xdade)[0]
				f := New(corpus)
				b.SetBytes(int64(n) * int64(d) * 4)
				b.ReportAllocs()
				b.ResetTimer()
				for i := 0; i < b.N; i++ {
					_ = f.Query(query, 10)
				}
			})
		}
	}
}

func BenchmarkHNSWBuild(b *testing.B) {
	corpus := makeUnitVectors(10_000, 256, 0xbeef)
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = BuildHNSW(corpus, Config{M: 16, EfConstruction: 200, EfSearch: 64, Seed: 1})
	}
}
