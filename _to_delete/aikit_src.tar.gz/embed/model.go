package embed

import (
	"encoding/json"
	"fmt"
	"io/fs"
	"os"
	"path"
)

// StaticModel is a Model2Vec static-embedding model. Goroutine-safe for
// concurrent Encode calls after Load returns — all internal state is
// immutable.
type StaticModel struct {
	tokenizer  *Tokenizer
	embeddings []float32 // [vocab × dim] flat, row-major
	mapping    []int64   // [vocab]
	weights    []float64 // [vocab]
	vocab      int
	dim        int
	normalize  bool

	// Keep the file alive so the unsafe-slice tensor data stays valid.
	st *SafetensorsFile
}

type modelConfig struct {
	Normalize              bool   `json:"normalize"`
	EmbeddingDType         string `json:"embedding_dtype"`
	VocabularyQuantization int    `json:"vocabulary_quantization"`
}

// LoadFromFS reads a Model2Vec model from fsys, rooted at dir. fsys must contain
//
//	<dir>/tokenizer.json
//	<dir>/config.json
//	<dir>/model.safetensors
//
// (the standard HF layout for Model2Vec models — typically a Hugging Face
// snapshot for minishlab/potion-code-16M or another compatible model).
//
// Typical call shapes:
//
//	LoadFromFS(os.DirFS("/path/to/model"), ".")     // load from a directory
//	LoadFromFS(embedFS, "model")                    // load from //go:embed model/*
//	LoadFromFS(mapFS, ".")                          // load from a fstest.MapFS
//
// Paths inside fsys follow the fs.FS slash convention (use the path
// package, not path/filepath). LoadFromFS is the canonical entry point;
// Load is a thin deprecated wrapper.
func LoadFromFS(fsys fs.FS, dir string) (*StaticModel, error) {
	join := func(name string) string { return path.Join(dir, name) }

	tok, err := LoadTokenizerFromFS(fsys, join("tokenizer.json"))
	if err != nil {
		return nil, fmt.Errorf("load tokenizer: %w", err)
	}

	cfgBytes, err := fs.ReadFile(fsys, join("config.json"))
	if err != nil {
		return nil, fmt.Errorf("read config.json: %w", err)
	}
	var cfg modelConfig
	if err := json.Unmarshal(cfgBytes, &cfg); err != nil {
		return nil, fmt.Errorf("parse config.json: %w", err)
	}
	if cfg.EmbeddingDType != "" && cfg.EmbeddingDType != "float32" {
		return nil, fmt.Errorf("unsupported embedding_dtype %q (only float32 supported)", cfg.EmbeddingDType)
	}

	st, err := OpenSafetensorsFromFS(fsys, join("model.safetensors"))
	if err != nil {
		return nil, fmt.Errorf("open safetensors: %w", err)
	}

	embT, err := st.Tensor("embeddings")
	if err != nil {
		return nil, fmt.Errorf("embeddings tensor: %w", err)
	}
	if len(embT.Shape) != 2 {
		return nil, fmt.Errorf("embeddings tensor: expected 2-D, got shape %v", embT.Shape)
	}
	vocab := embT.Shape[0]
	dim := embT.Shape[1]

	embData, err := embT.Float32s()
	if err != nil {
		return nil, err
	}
	if len(embData) != vocab*dim {
		return nil, fmt.Errorf("embeddings element count %d != vocab*dim (%d*%d)", len(embData), vocab, dim)
	}

	// mapping + weights are optional. The original potion format (vocabulary-
	// quantized, e.g. potion-code-16M) indexes embeddings through mapping[id] and
	// pools with per-token zipf weights[id]. The newer/standard Model2Vec format
	// (e.g. potion-retrieval-32M) bakes both in: embeddings are indexed directly by
	// token id and pooled with uniform weights (plain mean). Absence ⇒ nil ⇒ the
	// direct / uniform path in encodeIDs.
	var mapData []int64
	if mapT, e := st.Tensor("mapping"); e == nil {
		if len(mapT.Shape) != 1 || mapT.Shape[0] != vocab {
			return nil, fmt.Errorf("mapping tensor: expected shape [%d], got %v", vocab, mapT.Shape)
		}
		if mapData, err = mapT.Int64s(); err != nil {
			return nil, err
		}
	}
	var wData []float64
	if wT, e := st.Tensor("weights"); e == nil {
		if len(wT.Shape) != 1 || wT.Shape[0] != vocab {
			return nil, fmt.Errorf("weights tensor: expected shape [%d], got %v", vocab, wT.Shape)
		}
		if wData, err = wT.Float64s(); err != nil {
			return nil, err
		}
	}

	return &StaticModel{
		tokenizer:  tok,
		embeddings: embData,
		mapping:    mapData,
		weights:    wData,
		vocab:      vocab,
		dim:        dim,
		normalize:  cfg.Normalize,
		st:         st,
	}, nil
}

// Load reads a Model2Vec model from a directory containing tokenizer.json,
// config.json, and model.safetensors.
//
// Deprecated: use LoadFromFS(os.DirFS(modelDir), ".") instead. Load is kept
// as a thin wrapper for callers that haven't migrated yet (v0.6.0+).
func Load(modelDir string) (*StaticModel, error) {
	return LoadFromFS(os.DirFS(modelDir), ".")
}

// VocabSize reports the embedding-table vocabulary size.
func (m *StaticModel) VocabSize() int { return m.vocab }

// Dim reports the embedding dimension.
func (m *StaticModel) Dim() int { return m.dim }

// Tokenizer returns the underlying tokenizer (useful for parity tests).
func (m *StaticModel) Tokenizer() *Tokenizer { return m.tokenizer }

// Encode tokenizes and embeds a single string.
//
// Algorithm (verified by golden test against StaticModel.encode()):
//
//	ids = tokenize(text)
//	rows[i] = embeddings[mapping[ids[i]]]      // F32 row, dim values
//	w[i]    = weights[ids[i]]                  // F64 scalar
//	v       = Σ rows[i]·w[i]                   // accumulate in F64
//	v       = v / Σ w[i]                       // F64
//	if normalize: v /= ‖v‖₂                    // F64 sum-of-squares
//	return float32(v)                          // cast at the end
//
// Precision contract: every accumulator (weighted-sum, weight-sum,
// sum-of-squares for L2) is float64. Embeddings stay float32 in memory;
// individual values are widened to float64 only at the multiply-accumulate
// step. Float32 accumulation breaks parity with the Python reference on
// inputs of more than a few dozen tokens. See pool.go for the matching
// implementation and the rationale.
//
// Returns a zero vector for empty inputs and for degenerate cases that
// would otherwise produce NaN (all-UNK on a long word, all-zero weight sum).
func (m *StaticModel) Encode(text string) []float32 {
	ids := m.tokenizer.Encode(text)
	return m.encodeIDs(ids)
}

// encodeIDs is the inner path used by Encode and by tests that supply raw IDs.
func (m *StaticModel) encodeIDs(ids []int32) []float32 {
	if len(ids) == 0 {
		return make([]float32, m.dim)
	}

	rows := make([][]float32, len(ids))
	w := make([]float64, len(ids))
	for i, id := range ids {
		if id < 0 || int(id) >= m.vocab {
			// Out-of-range id — treat as a no-op token (zero contribution).
			// Skip via zero weight; the corresponding row stays nil and is
			// handled by the pool helper.
			rows[i] = nil
			w[i] = 0
			continue
		}
		embRow := int64(id) // standard format: token id indexes embeddings directly
		if m.mapping != nil {
			embRow = m.mapping[id] // quantized format: indirect through mapping[]
		}
		if embRow < 0 || int(embRow) >= m.vocab {
			rows[i] = nil
			w[i] = 0
			continue
		}
		start := int(embRow) * m.dim
		rows[i] = m.embeddings[start : start+m.dim]
		w[i] = 1.0 // uniform (plain mean) when no explicit weights
		if m.weights != nil {
			w[i] = m.weights[id]
		}
	}

	pooled := weightedMeanPoolSafe(rows, w, m.dim)
	if m.normalize {
		pooled = l2Normalize(pooled)
	}
	return pooled
}

// weightedMeanPoolSafe computes Σ rows[i]·weights[i] / Σ weights[i], the
// verified Model2Vec runtime pooling algorithm. Tolerates nil rows
// (treated as zero contribution; used when ids contain out-of-range values).
//
// `rows` is a logical [N, dim] view: rows[i] is a slice of length dim into
// the embeddings tensor (F32). `weights` is length N (F64 from the model).
//
// PRECISION CONTRACT (required for golden-test parity):
//   - All accumulators (sum[dim], wsum, the dot product inside L2 norm) are
//     float64. Each `rows[i][j]` (float32) is widened to float64 BEFORE
//     multiplying by w[i] and accumulating.
//   - Output is float32 (cast at the end), matching numpy's
//     `embeddings[...].astype(np.float64) ... .astype(np.float32)` shape
//     in pin_inference.py.
//
// Doing the accumulation in float32 will silently drift cosine below the
// 1 − 1e-5 parity bar on longer inputs. This is the single most likely
// silent failure mode for a re-implementer; do not "optimize" it away.
//
// Returns a zero vector if N==0 or Σweights == 0 (an all-pad / all-zero-weight
// degenerate case).
func weightedMeanPoolSafe(rows [][]float32, weights []float64, dim int) []float32 {
	out := make([]float32, dim)
	if len(rows) == 0 {
		return out
	}
	sum := make([]float64, dim)
	var wsum float64
	for i, row := range rows {
		if row == nil {
			continue
		}
		ww := weights[i]
		for j := range dim {
			sum[j] += float64(row[j]) * ww
		}
		wsum += ww
	}
	if wsum == 0 {
		return out
	}
	for j := range dim {
		out[j] = float32(sum[j] / wsum)
	}
	return out
}
